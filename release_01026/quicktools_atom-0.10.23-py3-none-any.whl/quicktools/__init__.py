"""
<div align="center">
  <img src="assets/AtomDev_Studios.png" alt="AtomDev Studios" width="400">
</div>

# quicktools

A math, text, media, and document automation toolkit — built by **Samuel Peprah**
under **AtomDev Studios**.

---

## About Samuel Peprah

<img src="assets/sam.png" alt="Samuel Peprah" width="150" style="border-radius: 50%; float: left; margin-right: 20px; margin-bottom: 10px; border: 2px solid #06b6d4;">

Samuel Peprah is a software developer, web application developer, and
Occupational Therapy student at the University of Ghana. Alongside his
healthcare education, he is also studying Computer Science at the University
of the People, combining knowledge from both fields to develop practical
technology solutions.

His interests span full-stack web development, software engineering,
automation, artificial intelligence, cybersecurity, and health technology.
He enjoys building scalable applications that solve real-world problems and
continuously explores new technologies to improve his skills.

Samuel has developed educational platforms, business management systems,
attendance systems, healthcare applications, and AI-powered solutions. He is
passionate about creating software that is modern, efficient, secure, and
user-friendly.

## About AtomDev Studios

AtomDev Studios is the personal software development brand founded by Samuel
Peprah. The studio specializes in designing and developing modern websites,
web applications, business management systems, educational platforms, and
custom software solutions for individuals, startups, schools, and
organizations.

The mission of AtomDev Studios is to transform ideas into reliable, scalable,
and innovative digital products that solve real-world problems while
delivering exceptional user experiences.

### Areas of Expertise

- Full-Stack Web Development
- Custom Web Applications
- REST API Development
- Database Design & Management
- Educational Technology Platforms
- Healthcare Technology Solutions
- AI Integration & Automation
- UI/UX Design
- Cloud Deployment & Hosting
- Website Maintenance & Support

### Technologies

Python • Flask • JavaScript • HTML • CSS • Tailwind CSS • Bootstrap •
PostgreSQL • SQLite • Git • GitHub • Cloudflare • Docker

### Connect

- LinkedIn: [samuel-peprah-a63598347](https://www.linkedin.com/in/samuel-peprah-a63598347)
- X (Twitter): [@legend_consult](https://x.com/legend_consult)
- TikTok: [@legendinlearning](https://www.tiktok.com/@legendinlearning)
- Instagram: [@ksapeprah](https://www.instagram.com/ksapeprah)
- GitHub: [Samuel-Peprah-cmd](https://github.com/Samuel-Peprah-cmd)

> "Building innovative software solutions that bridge technology with real-world impact."

---

### Modules:
- `mathtools` - primes, GCD/LCM, mean, median, standard deviation
- `strtools` - palindromes, slugify, edit distance, anagrams, ciphers
- `linalg` - matrix operations, determinants, inverses, linear systems
- `calculus` - derivatives, integrals, Taylor series, Newton's method
- `numbertheory` - extended GCD, modular inverse, sieve, prime factorization
- `combinatorics` - permutations, combinations, Catalan numbers, Fibonacci
- `filetools` - read/write any file, JSON, YAML, hashing, zip/unzip
- `imagetools` - AI background removal, format conversions, compress images, resize, watermark, image-to-PDF
- `pdftools` - merge, split/extract pages, compress PDFs, text extraction, rotate, encrypt, PDF-to-images
- `doctools` - read/write Word docs, compress heavy .docx files, docx-to-PDF, PDF-to-docx
- `spreadsheettools` - CSV, Excel, and JSON conversions
- `unitconverter` - temperature, distance, weight, volume, speed, storage conversions
- `presentationtools` - read/create PowerPoint decks, cloud themes, docx/pdf-to-pptx, pptx-to-docx
- `audiotools` - AI transcription, AI translation to English, word timestamps, speaker diarization, SRT export
- `videotools` - web video downloader, audio extraction, video transcription, frame extraction
"""

__version__ = "0.10.23"